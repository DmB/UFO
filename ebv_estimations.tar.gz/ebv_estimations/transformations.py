from astropy import units as u
from astropy import coordinates as coord
#from astropy_healpix import HEALPix

ra=[]
dec=[]
p=[]
perr=[]
evpa=[]
evpa_err=[]
heal=[]
ebv=[]
ebv_err=[]
ebv_err2=[]
nside=[]

fop = open('asu2.csv')
fop2 = open('lonlatebv.csv','w+')
fop3 = open('EBV2.csv')

for line in fop.readlines():
    if line.startswith('#'):
        continue
    sl=line.split(',')
    ra.append(str(sl[0]))
    dec.append(str(sl[1]))
    p.append(str(sl[2]))
    perr.append(str(sl[3]))
    evpa.append(str(sl[4]))
    evpa_err.append(str(sl[5]))
    
for line in fop3.readlines():
    if line.startswith('#'):
        continue
    sl=line.split(',')
    heal.append(str(sl[0]))
    ebv_err.append(str(sl[3]))
    ebv_err2.append(str(sl[4]))
    ebv.append(str(sl[5]))
    nside.append(str(sl[7]))


fop2.write(str('#l,b,ra,dec,HEALPix,p,perr,evpa,evpa_err,ebv,ebv_err,ebv_err2'))
fop2.write('\n')
for i in range(len(ra)):
    c=coord.ICRSCoordinates(ra=ra[i], dec=dec[i], unit=(u.degree, u.degree)) 
    g = c.transform_to(coord.GalacticCoordinates)
    #print g
    fop2.write(str(g.l.degree))
    fop2.write(',')
    fop2.write(str(g.b.degree))
    #hp = HEALPix(nside=256, order='nested')
    #hp_find = hp.lonlat_to_healpix(g.l.degree,g.b.degree,return_offsets=False)
    fop2.write(',')
    fop2.write(str(ra[i]))
    fop2.write(',')
    fop2.write(str(dec[i]))
    fop2.write(',')
    #fop2.write(str(hp_find))
    fop2.write(',')
    fop2.write(str(p[i]))
    fop2.write(',')
    fop2.write(str(perr[i]))
    fop2.write(',')
    fop2.write(str(evpa[i]))
    fop2.write(',')
    fop2.write(str(evpa_err[i]))
    #fop2.write(',')
    #fop2.write(str(ebv[float(hp_find)]))
    #fop2.write(',')
    #fop2.write(str(ebv_err[float(hp_find)]))
    #fop2.write(',')
    #fop2.write(str(ebv_err2[float(hp_find)]))
    

fop.close()
fop2.close()
fop3.close()