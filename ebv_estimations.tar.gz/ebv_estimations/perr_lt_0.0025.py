


ra=[]
dec=[]
p=[]
perr=[]
evpa=[]
evpa_err=[]
#ra1=[]
#dec1=[]
#p1=[]
#perr1=[]
#evpa1=[]
#evpa_err1=[]
fop = open('asu.csv')
fop2 = open('asu2.csv','w+')
c=0
for line in fop.readlines():
    if line.startswith('#'):
        continue
    sl=line.split(',')
    ra.append(str(sl[0]))
    dec.append(str(sl[1]))
    p.append(str(sl[6]))
    perr.append(str(sl[7]))
    evpa.append(str(sl[8]))
    evpa_err.append(str(sl[9]))
    c+=1
print 'asu count ',c
#j=0    
c1=0
fop2.write(str('#RA DEC p p_err EVPA EVPA_err'))
fop2.write('\n')
for i in range(len(ra)):
    if float(perr[i]) < 0.0025:
        fop2.write(str(ra[i]))
        fop2.write(',')
        fop2.write(str(dec[i]))
        fop2.write(',')
        fop2.write(str(p[i]))
        fop2.write(',')
        fop2.write(str(perr[i]))
        fop2.write(',')
        fop2.write(str(evpa[i]))
        fop2.write(',')
        fop2.write(str(evpa_err[i]))
        fop2.write('\n')
        c1+=1
print 'asu2 count ',c1

fop.close()
fop2.close()