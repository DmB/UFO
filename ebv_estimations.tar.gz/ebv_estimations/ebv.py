


status=[]
nstar=[]
err=[]
err2=[]
ebv=[]
nstar_tot=[]
nside=[]

fop = open('EBV.csv')
fop2 = open('EBV2.csv','w+')

for line in fop.readlines():
    if line.startswith('#'):
        continue
    sl=line.split(',')
    status.append(str(sl[0]))
    nstar.append(str(sl[1]))
    err.append(str(sl[2]))
    err2.append(str(sl[3]))
    ebv.append(str(sl[4]))
    nstar_tot.append(str(sl[5]))
    nside.append(str(sl[6]))


   
c1=0

fop2.write('#HEALPix,status,nstar,err,err2,ebv,nstar_tot,nside')
fop2.write('\n')
for i in range(len(status)):
    if str(status[i]) == '1' or str(status[i]) == '-1':
        fop2.write(str(c1))
        fop2.write(',')
        fop2.write(str(status[i]))
        fop2.write(',')
        fop2.write(str(nstar[i]))
        fop2.write(',')
        fop2.write(str(err[i]))
        fop2.write(',')
        fop2.write(str(err2[i]))
        fop2.write(',')
        fop2.write(str(ebv[i]))
        fop2.write(',')
        fop2.write(str(nstar_tot[i]))
        fop2.write(',')
        fop2.write(str(nside[i]))

    c1+=1
     

fop.close()
fop2.close()
